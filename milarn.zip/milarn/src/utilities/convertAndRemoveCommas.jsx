function convertAndRemoveCommas(arr) {
    // Convert the array to a string and remove commas
    return arr.join('');
}

export default convertAndRemoveCommas