import CryptoJS from 'crypto-js';

export default function encryptor({text}) {
    
 
}
// const msg = res.data.msg
// const secretKey = "Ifeoluwa"
// const cipherText = CryptoJS.AES.encrypt(msg, secretKey).toString()
// const plainText = CryptoJS.AES.decrypt(cipherText, secretKey).toString(CryptoJS.enc.Utf8)