export default function CountSlashes(inputString) {
    return inputString.split('/').length - 1;
  }