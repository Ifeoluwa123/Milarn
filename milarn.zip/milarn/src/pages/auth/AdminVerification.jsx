import React, { useEffect, useState } from 'react'
import HeaderForm from '../../components/shared/HeaderForm'
import SubheaderForm from '../../components/shared/SubheaderForm'
import LoginForm from '../../components/auth/admin/LoginForm'
import HelloHand from '../../assets/images/hand.png'
import TokenVerificationForm from '../../components/auth/admin/TokenVerificationForm'
export default function AdminVerification() {
  const [otpSentMsg , setOTPSentMsg] = useState({
    error:'',
    success:'' 
});


// useEffect(()=>{
//   if (otpSentMsg){
//     console.log(otpSentMsg)
//   }
// },[otpSentMsg])
// // 
  return (
    <div className='containers '>

      
        <HeaderForm text='Don’t have an account? ' linkText='Create an account' path="/register" />

        {/* <div className="border- px-[1rem] md:px-[2rem] pb-[3rem]  max-w-[500px] md:max-w-[765px] w-full mx-auto  mt-[3rem]"> */}
        <div className=" px-[1rem] md:px-[2rem] pb-[3rem] max-w-[500px]  md:max-w-[765px] lg:max-w-[500px]  w-full mx-auto mt-[3rem]  lg:mt-[6rem]">
           
           
            <SubheaderForm className="mt-[2rem]" label="Confirm email address" desc="Please input  the 4 characters sent to your email" />
        
        <div className="mt-[1rem]">

        {
          otpSentMsg.error && 
          <div className={`bg-[#FDEAEA] text-[#FE5E55] mb-[1rem] rounded-[4px] w-fit p-[4px_20px_4px_20px]`}>
                Error: {otpSentMsg.error}
        </div>
         } 
         {
          otpSentMsg.success && 
          <div className={`bg-[#F2FDF5] text-[#21C45D] mb-[1rem] rounded-[4px] w-fit p-[4px_20px_4px_20px]`}>
                {otpSentMsg.success}
        </div>
         }
        </div>
         
              <div className="mt-[1rem]">
              <TokenVerificationForm otpSentMsg = {otpSentMsg}  setOTPSentMsg={setOTPSentMsg} />

              </div>
        </div>

    </div>
  )
}


